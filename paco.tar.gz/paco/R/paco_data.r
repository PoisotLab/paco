#' Gopher phylogeny
#' @docType data
#' @keywords datasets
#' @name gophertree
#' @usage data(gopherlice)
NULL

#' Lice phylogeny
#' @docType data
#' @keywords datasets
#' @name licetree
#' @usage data(gopherlice)
NULL

#' Gopher/lice phylogenies
#' @docType data
#' @keywords datasets
#' @name gl_links
#' @usage data(gopherlice)
NULL
